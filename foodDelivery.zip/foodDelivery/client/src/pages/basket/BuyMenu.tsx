import React from "react";
import "../../App.css";
import axios from "axios";
import { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";

//for balance
export function BuyMenu() {
    return (
        <>

            buy

        </>

    );
}
