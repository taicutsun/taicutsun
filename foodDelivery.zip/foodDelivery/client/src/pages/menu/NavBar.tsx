import "./NavBar.css";

import React, { useState } from "react";
import { Link } from "react-router-dom";


export const NavBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  return (
    <>
      <button
        className={`menu-button ${isMenuOpen ? "active" : ""}`}
        onClick={() => setIsMenuOpen(!isMenuOpen)}
      >
        ≡
      </button>
      {isMenuOpen && (
        <nav className="navMenu"> 
          <ul>
            <li>
              <Link className="link" to="/posts">
                Главная
              </Link>
            </li>
            <li>
              <Link className="link" to="/basket">
                Корзина
              </Link>
            </li>
            <li>
              <Link className="link" to="/balance">
                Пополнить баланск
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </>
  );
};


